#include <stdio.h>

// 函数声明
int sum(int n);

int main() {
    int n;
    
    // 从键盘读入n的数值
    printf("请输入一个正整数n: ");
    scanf("%d", &n);
    
    // 检查输入是否有效
    if (n < 1) {
        printf("错误：请输入一个正整数！\n");
        return 1;
    }
    
    // 调用子程序计算总和
    int result = sum(n);
    
    // 输出结果
    printf("sum=%d\n", result);
    
    return 0;
}

// 子程序实现：计算1到n的和
int sum(int n) {
    int s = 0;
    for (int i = 1; i <= n; i++) {
        s += i;
    }
    return s;
}