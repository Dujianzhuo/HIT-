#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 定义学生信息结构体
typedef struct {
    int id;                 // 学生编号
    char name[50];         // 姓名
    float scores[3];       // 3个课程分数
    int weight;           // 体重
} Student;

// 从文件读取数据
int readStudents(const char* filename, Student* students, int maxSize) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("无法打开输入文件 %s\n", filename);
        return -1;
    }

    int count = 0;
    while (count < maxSize && 
           fscanf(file, "%d %s %f %f %f %d", 
                 &students[count].id, 
                 students[count].name, 
                 &students[count].scores[0], 
                 &students[count].scores[1], 
                 &students[count].scores[2], 
                 &students[count].weight) == 6) {
        count++;
    }

    fclose(file);
    return count;
}

// 写入数据到文件
void writeStudents(const char* filename, Student* students, int count) {
    FILE* file = fopen(filename, "w");
    if (file == NULL) {
        printf("无法打开输出文件 %s\n", filename);
        return;
    }

    for (int i = 0; i < count; i++) {
        fprintf(file, "%d %s %.2f %.2f %.2f %d\n", 
                students[i].id, 
                students[i].name, 
                students[i].scores[0], 
                students[i].scores[1], 
                students[i].scores[2], 
                students[i].weight);
    }

    fclose(file);
}

int main() {
    const int MAX_STUDENTS = 100;
    Student students[MAX_STUDENTS];
    
    // 从input.txt读取数据
    int count = readStudents("input.txt", students, MAX_STUDENTS);
    if (count < 0) {
        printf("读取文件失败\n");
        return 1;
    }
    
    printf("成功读取 %d 条学生记录\n", count);

    // 写入数据到output.txt
    writeStudents("output.txt", students, count);
    printf("数据已成功写入到output.txt\n");

    return 0;
}
