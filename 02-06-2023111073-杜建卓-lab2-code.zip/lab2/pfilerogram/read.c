#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE 100

int main() {
    float numbers[ARRAY_SIZE];
    FILE* file = fopen("float_binary.bin", "rb");
    
    if (file == NULL) {
        printf("无法打开文件 float_binary.bin\n");
        return 1;
    }
    
    // 读取二进制文件中的浮点数数组
    size_t count = fread(numbers, sizeof(float), ARRAY_SIZE, file);
    fclose(file);
    
    if (count != ARRAY_SIZE) {
        printf("读取数据不完整，只读取到 %zu 个数\n", count);
    }
    
    // 显示读取到的数据
    printf("从float_binary.bin读取到的%d个浮点数：\n", ARRAY_SIZE);
    printf("----------------------------------------\n");
    for (int i = 0; i < count; i++) {
        printf("第%3d个数：%6.2f\n", i + 1, numbers[i]);
    }
    
    return 0;
}
