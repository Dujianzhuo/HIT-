#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 定义学生信息结构体
typedef struct {
    int id;                // 学生编号
    char name[50];         // 姓名
    float scores[3];       // 3个课程分数
    int weight;           // 体重
} Student;

// 写入结构体数组到二进制文件
void writeStudentsBinary(const char* filename, Student* students, int count) {
    FILE* file = fopen(filename, "wb");  // 以二进制写入模式打开
    if (file == NULL) {
        printf("无法创建二进制文件 %s\n", filename);
        return;
    }

    // 直接写入整个结构体数组
    size_t written = fwrite(students, sizeof(Student), count, file);
    if (written != count) {
        printf("写入数据不完整，只写入了 %zu 条记录\n", written);
    } else {
        printf("成功写入 %zu 条学生记录到二进制文件\n", written);
    }

    fclose(file);
}

// 从二进制文件读取结构体数组
// 返回读取到的记录数量
int readStudentsBinary(const char* filename, Student** students) {
    FILE* file = fopen(filename, "rb");  // 以二进制读取模式打开
    if (file == NULL) {
        printf("无法打开二进制文件 %s\n", filename);
        return -1;
    }

    // 获取文件大小
    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    // 计算记录数量
    int recordCount = fileSize / sizeof(Student);
    if (fileSize % sizeof(Student) != 0) {
        printf("警告：文件大小不是结构体大小的整数倍\n");
    }

    // 分配内存
    *students = (Student*)malloc(recordCount * sizeof(Student));
    if (*students == NULL) {
        printf("内存分配失败\n");
        fclose(file);
        return -1;
    }

    // 读取所有记录
    size_t read = fread(*students, sizeof(Student), recordCount, file);
    if (read != recordCount) {
        printf("读取数据不完整，只读取到 %zu 条记录\n", read);
    } else {
        printf("成功读取 %zu 条学生记录\n", read);
    }

    fclose(file);
    return read;
}

// 显示学生信息
void displayStudent(Student* student) {
    printf("ID: %d, 姓名: %s\n", student->id, student->name);
    printf("成绩: %.2f, %.2f, %.2f\n", 
           student->scores[0], student->scores[1], student->scores[2]);
    printf("体重: %d\n", student->weight);
    printf("------------------------\n");
}

int main() {
    // 创建示例数据
    Student students[] = {
        {1001, "张三", {85.5, 92.0, 78.5}, 65},
        {1002, "李四", {90.0, 88.5, 95.0}, 70},
        {1003, "王五", {76.5, 82.0, 88.5}, 68}
    };
    int originalCount = sizeof(students) / sizeof(Student);

    // 写入二进制文件
    const char* filename = "students.bin";
    writeStudentsBinary(filename, students, originalCount);

    // 从二进制文件读取数据
    Student* readStudents = NULL;
    int readCount = readStudentsBinary(filename, &readStudents);

    if (readCount > 0 && readStudents != NULL) {
        printf("\n读取到的学生信息：\n");
        for (int i = 0; i < readCount; i++) {
            printf("\n第 %d 个学生：\n", i + 1);
            displayStudent(&readStudents[i]);
        }
        free(readStudents);  // 释放动态分配的内存
    }

    return 0;
}
