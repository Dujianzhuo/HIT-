#ifndef FILEOP_H
#define FILEOP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

// 定义结构体
struct myrecord {
    unsigned long id;
    char name[32];
    float score[3];
    int weight;
};

// 函数声明
int read_text_write_binary(const char *text_file, const char *binary_file);
int read_binary_write_text(const char *binary_file, const char *text_file);
void print_record(const struct myrecord *record);

#endif