#include "fileop.h"
#include <stdio.h>

/**
 * 功能：主程序，根据命令行参数调用相应功能
 * 参数：argc - 参数个数，argv - 参数数组
 * 返回值：成功返回0，失败返回1
 */
int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage:\n");
        printf("  Function 1: %s 1 text_file binary_file\n", argv[0]);
        printf("  Function 2: %s 2 binary_file text_file\n", argv[0]);
        return 1;
    }

    int function = atoi(argv[1]);
    int result;

    switch (function) {
        case 1:
            result = read_text_write_binary(argv[2], argv[3]);
            if (result == 0) {
                printf("Function 1 completed successfully.\n");
            } else {
                printf("Function 1 failed.\n");
                return 1;
            }
            break;
        
        case 2:
            result = read_binary_write_text(argv[2], argv[3]);
            if (result == 0) {
                printf("Function 2 completed successfully.\n");
            } else {
                printf("Function 2 failed.\n");
                return 1;
            }
            break;
        
        default:
            printf("Invalid function number. Use 1 or 2.\n");
            return 1;
    }

    return 0;
}
