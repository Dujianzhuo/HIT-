#include "fileop.h"

/**
 * 功能：从文本文件读取数据并写入二进制文件
 * 参数：text_file - 文本文件路径，binary_file - 二进制文件路径
 * 返回值：成功返回0，失败返回-1
 */
int read_text_write_binary(const char *text_file, const char *binary_file) {
    FILE *fp_text = fopen(text_file, "r");
    if (fp_text == NULL) {
        printf("Error opening text file %s: error %d : %s\n", 
               text_file, errno, strerror(errno));
        return -1;
    }

    FILE *fp_binary = fopen(binary_file, "wb");
    if (fp_binary == NULL) {
        printf("Error opening binary file %s: error %d : %s\n", 
               binary_file, errno, strerror(errno));
        fclose(fp_text);
        return -1;
    }

    struct myrecord record;
    char line[256];
    int line_num = 0;

    while (fgets(line, sizeof(line), fp_text) != NULL) {
        line_num++;
        // 解析文本行
        int result = sscanf(line, "%lu %31s %f %f %f %d", 
                          &record.id, record.name, 
                          &record.score[0], &record.score[1], &record.score[2], 
                          &record.weight);
        
        if (result != 6) {
            printf("Error parsing line %d: expected 6 values, got %d\n", 
                   line_num, result);
            continue;
        }

        // 写入二进制文件
        size_t written = fwrite(&record, sizeof(struct myrecord), 1, fp_binary);
        if (written != 1) {
            printf("Error writing to binary file at line %d: error %d : %s\n", 
                   line_num, errno, strerror(errno));
        }

        // 输出到屏幕
        print_record(&record);
    }

    fclose(fp_text);
    fclose(fp_binary);
    return 0;
}

/**
 * 功能：从二进制文件读取数据并写入文本文件
 * 参数：binary_file - 二进制文件路径，text_file - 文本文件路径
 * 返回值：成功返回0，失败返回-1
 */
int read_binary_write_text(const char *binary_file, const char *text_file) {
    FILE *fp_binary = fopen(binary_file, "rb");
    if (fp_binary == NULL) {
        printf("Error opening binary file %s: error %d : %s\n", 
               binary_file, errno, strerror(errno));
        return -1;
    }

    FILE *fp_text = fopen(text_file, "w");
    if (fp_text == NULL) {
        printf("Error opening text file %s: error %d : %s\n", 
               text_file, errno, strerror(errno));
        fclose(fp_binary);
        return -1;
    }

    struct myrecord record;
    size_t records_read;

    while ((records_read = fread(&record, sizeof(struct myrecord), 1, fp_binary)) == 1) {
        // 输出到屏幕
        print_record(&record);
        
        // 写入文本文件
        fprintf(fp_text, "%lu %s %.2f %.2f %.2f %d\n", 
                record.id, record.name, 
                record.score[0], record.score[1], record.score[2], 
                record.weight);
    }

    if (ferror(fp_binary)) {
        printf("Error reading binary file: error %d : %s\n", 
               errno, strerror(errno));
    }

    fclose(fp_binary);
    fclose(fp_text);
    return 0;
}

/**
 * 功能：格式化输出一个记录到屏幕
 * 参数：record - 指向要输出的结构体指针
 */
void print_record(const struct myrecord *record) {
    printf("%lu %s %.2f %.2f %.2f %d\n", 
           record->id, record->name, 
           record->score[0], record->score[1], record->score[2], 
           record->weight);
}