#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARRAY_SIZE 100

// 用于存储文件信息的结构体
typedef struct {
    char filename[50];
    long size;
} FileInfo;

// 获取文件大小
long getFileSize(const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (file == NULL) {
        printf("无法打开文件 %s\n", filename);
        return -1;
    }
    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    fclose(file);
    return size;
}

// 初始化数组
void initArrays(float* floatArray, char* charArray) {
    // 初始化浮点数组（使用一些带小数点的值）
    for(int i = 0; i < ARRAY_SIZE; i++) {
        floatArray[i] = i + 0.5;
    }
    
    // 初始化字符数组（使用可打印字符）
    for(int i = 0; i < ARRAY_SIZE; i++) {
        charArray[i] = 'A' + (i % 26); // 循环使用字母A-Z
    }
}

// 写入二进制文件
void writeBinaryFile(const void* array, size_t elementSize, size_t count, const char* filename) {
    FILE* file = fopen(filename, "wb");
    if (file == NULL) {
        printf("无法创建二进制文件 %s\n", filename);
        return;
    }
    fwrite(array, elementSize, count, file);
    fclose(file);
}

// 写入文本文件
void writeTextFile(const void* array, int isFloat, const char* filename) {
    FILE* file = fopen(filename, "w");
    if (file == NULL) {
        printf("无法创建文本文件 %s\n", filename);
        return;
    }
    
    for(int i = 0; i < ARRAY_SIZE; i++) {
        if (isFloat) {
            fprintf(file, "%.2f\n", ((float*)array)[i]);
        } else {
            fprintf(file, "%c\n", ((char*)array)[i]);
        }
    }
    fclose(file);
}

// 显示文件内容预览
void showFilePreview(const char* filename, int isBinary) {
    FILE* file = fopen(filename, isBinary ? "rb" : "r");
    if (file == NULL) {
        printf("无法打开文件 %s\n", filename);
        return;
    }

    printf("\n%s 的前10个元素：\n", filename);
    
    if (isBinary) {
        // 对于二进制文件，我们读取实际的字节
        unsigned char buffer[10];
        size_t read = fread(buffer, 1, 10, file);
        for(size_t i = 0; i < read; i++) {
            printf("%02X ", buffer[i]);
        }
        printf("\n");
    } else {
        // 对于文本文件，我们按行读取
        char line[100];
        int count = 0;
        while(count < 10 && fgets(line, sizeof(line), file)) {
            printf("%s", line);
            count++;
        }
    }
    
    fclose(file);
}

int main() {
    float floatArray[ARRAY_SIZE];
    char charArray[ARRAY_SIZE];
    FileInfo files[4];
    
    // 初始化数组
    initArrays(floatArray, charArray);
    
    // 写入文件
    writeBinaryFile(floatArray, sizeof(float), ARRAY_SIZE, "float_binary.bin");
    writeBinaryFile(charArray, sizeof(char), ARRAY_SIZE, "char_binary.bin");
    writeTextFile(floatArray, 1, "float_text.txt");
    writeTextFile(charArray, 0, "char_text.txt");
    
    // 准备文件信息
    strcpy(files[0].filename, "float_binary.bin");
    strcpy(files[1].filename, "float_text.txt");
    strcpy(files[2].filename, "char_binary.bin");
    strcpy(files[3].filename, "char_text.txt");
    
    // 获取并显示文件大小
    printf("\n文件大小比较：\n");
    printf("----------------------------------------\n");
    for(int i = 0; i < 4; i++) {
        files[i].size = getFileSize(files[i].filename);
        printf("%-15s: %ld 字节\n", files[i].filename, files[i].size);
    }
    
    // 显示文件内容预览
    printf("\n文件内容预览：\n");
    printf("----------------------------------------\n");
    showFilePreview("float_binary.bin", 1);
    showFilePreview("float_text.txt", 0);
    showFilePreview("char_binary.bin", 1);
    showFilePreview("char_text.txt", 0);
    
    return 0;
}
