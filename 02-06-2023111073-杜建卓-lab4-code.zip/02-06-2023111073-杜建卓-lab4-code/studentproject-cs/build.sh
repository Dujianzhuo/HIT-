#!/bin/bash

echo "检查目录结构..."
if [ ! -d "client" ]; then
    echo "创建client目录..."
    mkdir client
    echo "请将client相关文件移动到client目录中"
    exit 1
fi

echo "构建common库..."
cd common && make && cd ..

echo "构建服务器..."
cd server && make && cd ..

echo "构建客户端..."
cd client && make && cd ..

echo "构建完成！"