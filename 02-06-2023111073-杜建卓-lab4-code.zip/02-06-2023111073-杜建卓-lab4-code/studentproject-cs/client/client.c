#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdint.h>
#include "client.h"
#include "../common/protocol.h"

static int client_socket = -1;

int connect_to_server() {
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        return -1;
    }
    
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        close(client_socket);
        client_socket = -1;
        return -1;
    }
    
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(client_socket);
        client_socket = -1;
        return -1;
    }
    
    printf("成功连接到服务器 %s:%d\n", SERVER_IP, PORT);
    return 0;
}

void send_request(MessageType type, RequestData *req) {
    if (client_socket < 0) {
        printf("未连接到服务器\n");
        return;
    }
    
    Message msg;
    msg.type = type;
    
    if (req) {
        msg.data_length = sizeof(RequestData);
        memcpy(msg.data, req, sizeof(RequestData));
    } else {
        msg.data_length = 0;
    }
    
    send(client_socket, &msg, sizeof(Message), 0);
}

ResponseData receive_response() {
    ResponseData resp = {0};
    
    if (client_socket < 0) {
        strcpy(resp.message, "未连接到服务器");
        return resp;
    }
    
    Message msg;
    int bytes_received = recv(client_socket, &msg, sizeof(Message), 0);
    
    if (bytes_received > 0 && (msg.type == MSG_RESPONSE_SUCCESS || msg.type == MSG_RESPONSE_ERROR)) {
        if (msg.data_length > 0) {
            memcpy(&resp, msg.data, sizeof(ResponseData));
        }
    } else {
        strcpy(resp.message, "接收响应失败");
    }
    
    return resp;
}

void close_connection() {
    if (client_socket >= 0) {
        close(client_socket);
        client_socket = -1;
        printf("连接已关闭\n");
    }
}

// 序列化函数
int serialize_request(RequestData *req, char *buffer) {
    memcpy(buffer, req, sizeof(RequestData));
    return sizeof(RequestData);
}

int deserialize_request(char *buffer, RequestData *req) {
    memcpy(req, buffer, sizeof(RequestData));
    return sizeof(RequestData);
}

int serialize_response(ResponseData *resp, char *buffer) {
    memcpy(buffer, resp, sizeof(ResponseData));
    return sizeof(ResponseData);
}

int deserialize_response(char *buffer, ResponseData *resp) {
    memcpy(resp, buffer, sizeof(ResponseData));
    return sizeof(ResponseData);
}