#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"
#include "../common/student.h"
#include "../common/fileop.h"
#include "../common/sort.h"
#include "../common/analysis.h"


void display_menu() {
    printf("\n========== 成绩管理系统 ==========\n");
    printf("1. 添加学生记录\n");
    printf("2. 按姓名查询\n");
    printf("3. 按学号查询\n");
    printf("4. 修改学生信息\n");
    printf("5. 删除学生信息\n");
    printf("6. 计算学生总分和平均分\n");
    printf("7. 计算班级平均分\n");
    printf("8. 按课程成绩排序\n");
    printf("9. 成绩统计分析\n");
    printf("10. 保存到文本文件\n");
    printf("11. 从文本文件加载\n");
    printf("12. 保存到二进制文件\n");
    printf("13. 从二进制文件加载\n");
    printf("14. 显示所有学生\n");
    printf("0. 退出\n");
    printf("==================================\n");
    printf("请选择操作: ");
}

int main() {
    CLASS my_class;
    init_class(&my_class);
    
    if (connect_to_server() < 0) {
        printf("连接服务器失败\n");
        return 1;
    }
    
    int choice;
    
    do {
        display_menu();
        scanf("%d", &choice);
        getchar(); // 清除换行符
        
        switch (choice) {
            case 1:
                add_student(&my_class);
                break;
            case 2: {
                char name[NAME_LENGTH];
                printf("请输入要查询的姓名: ");
                scanf("%s", name);
                int index = search_by_name(&my_class, name);
                if (index != -1) {
                    display_student(&my_class.students[index]);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
            case 3: {
                char id[ID_LENGTH];
                printf("请输入要查询的学号: ");
                scanf("%s", id);
                int index = search_by_id(&my_class, id);
                if (index != -1) {
                    display_student(&my_class.students[index]);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
            case 4: {
                char id[ID_LENGTH];
                printf("请输入要修改的学生学号: ");
                scanf("%s", id);
                int index = search_by_id(&my_class, id);
                if (index != -1) {
                    modify_student(&my_class, index);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
            case 5: {
                char id[ID_LENGTH];
                printf("请输入要删除的学生学号: ");
                scanf("%s", id);
                int index = search_by_id(&my_class, id);
                if (index != -1) {
                    delete_student(&my_class, index);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
            case 6:
                calculate_student_stats(&my_class);
                break;
            case 7:
                calculate_class_stats(&my_class);
                break;
            case 8: {
                printf("请选择排序的课程:\n");
                printf("1. 计算机系统\n2. 程序设计实践\n3. 数据结构\n4. 数字逻辑\n5. 总分\n");
                int course_choice;
                scanf("%d", &course_choice);
                sort_by_course(&my_class, course_choice);
                break;
            }
            case 9: {
                printf("请选择分析的课程:\n");
                printf("1. 计算机系统\n2. 程序设计实践\n3. 数据结构\n4. 数字逻辑\n");
                int course_choice;
                scanf("%d", &course_choice);
                statistic_analysis(&my_class, course_choice);
                break;
            }
            case 10:
                save_to_text_file(&my_class, "students.txt");
                break;
            case 11:
                load_from_text_file(&my_class, "students.txt");
                break;
            case 12:
                save_to_binary_file(&my_class, "students.dat");
                break;
            case 13:
                load_from_binary_file(&my_class, "students.dat");
                break;
            case 14:
                display_all_students(&my_class);
                break;
            case 0:
                send_request(MSG_EXIT, NULL);
                printf("感谢使用成绩管理系统！\n");
                break;
            default:
                printf("无效的选择，请重新输入！\n");
        }
        
        printf("\n按回车键继续...");
        getchar();
        
    } while (choice != 0);
    
    close_connection();
    return 0;
}