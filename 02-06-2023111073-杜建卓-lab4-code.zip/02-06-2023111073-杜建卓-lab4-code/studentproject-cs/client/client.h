#ifndef CLIENT_H
#define CLIENT_H

#include "../common/protocol.h"
#include "../common/student.h"

#define SERVER_IP "127.0.0.1"
#define PORT 8888

// 网络连接函数
int connect_to_server();
void send_request(MessageType type, RequestData *req);
ResponseData receive_response();
void close_connection();

// 序列化/反序列化函数（简化签名）
int serialize_request(RequestData *req, char *buffer);
int deserialize_request(char *buffer, RequestData *req);
int serialize_response(ResponseData *resp, char *buffer);
int deserialize_response(char *buffer, ResponseData *resp);

#endif