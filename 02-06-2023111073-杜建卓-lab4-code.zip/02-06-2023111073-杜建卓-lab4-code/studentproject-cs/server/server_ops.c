#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include "../common/student.h"
#include "../common/fileop.h"
#include "../common/sort.h"
#include "../common/analysis.h"
#include "server.h"

extern CLASS global_class;
extern pthread_mutex_t class_mutex;

// 在server_ops.c开头添加这些函数声明
int search_by_name(CLASS *class, const char *name);
int search_by_id(CLASS *class, const char *id);
void calculate_student_stats(CLASS *class);
void calculate_class_stats(CLASS *class);
void init_class(CLASS *class);

