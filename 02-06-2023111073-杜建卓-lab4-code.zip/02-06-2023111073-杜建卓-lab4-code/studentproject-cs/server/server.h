#ifndef SERVER_H
#define SERVER_H

#include "../common/protocol.h"
#include "../common/student.h"

#define PORT 8888
#define MAX_CLIENTS 10
#define BUFFER_SIZE 2048

void handle_client(int client_socket);
void process_message(int client_socket, Message *msg);
int serialize_response(ResponseData *resp, char *buffer);
int deserialize_request(char *buffer, RequestData *req);  // 移除MessageType参数


extern CLASS global_class;
extern pthread_mutex_t class_mutex;

#endif