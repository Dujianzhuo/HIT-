#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdint.h>
#include "server.h"
#include "server_ops.c"

CLASS global_class;
pthread_mutex_t class_mutex = PTHREAD_MUTEX_INITIALIZER;


void init_server() {
    pthread_mutex_lock(&class_mutex);
    init_class(&global_class);
    pthread_mutex_unlock(&class_mutex);
}

void process_add_student(RequestData *req, ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    if (global_class.count >= MAX_STUDENTS) {
        resp->success = 0;
        strcpy(resp->message, "班级已满，无法添加更多学生！");
    } else {
        global_class.students[global_class.count] = req->student;
        global_class.count++;
        resp->success = 1;
        strcpy(resp->message, "学生信息添加成功！");
    }
    
    pthread_mutex_unlock(&class_mutex);
}

void process_search_by_name(RequestData *req, ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    int index = search_by_name(&global_class, req->search_key);
    if (index != -1) {
        resp->success = 1;
        resp->student = global_class.students[index];
        strcpy(resp->message, "找到学生");
    } else {
        resp->success = 0;
        strcpy(resp->message, "未找到该学生！");
    }
    
    pthread_mutex_unlock(&class_mutex);
}

void process_search_by_id(RequestData *req, ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    int index = search_by_id(&global_class, req->search_key);
    if (index != -1) {
        resp->success = 1;
        resp->student = global_class.students[index];
        strcpy(resp->message, "找到学生");
    } else {
        resp->success = 0;
        strcpy(resp->message, "未找到该学生！");
    }
    
    pthread_mutex_unlock(&class_mutex);
}

void process_calc_student_stats(ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    // 移除未使用的buffer变量
    calculate_student_stats(&global_class);
    resp->success = 1;
    strcpy(resp->message, "学生成绩统计计算完成");
    
    pthread_mutex_unlock(&class_mutex);
}

void process_calc_class_stats(ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    calculate_class_stats(&global_class);
    resp->success = 1;
    snprintf(resp->message, sizeof(resp->message),
             "班级平均成绩: ICS=%.2f, PDP=%.2f, DS=%.2f, DL=%.2f",
             global_class.ics_avg, global_class.pdp_avg,
             global_class.ds_avg, global_class.dl_avg);
    
    pthread_mutex_unlock(&class_mutex);
}

void process_display_all(ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    resp->class_data = global_class;
    resp->success = 1;
    strcpy(resp->message, "获取所有学生数据成功");
    
    pthread_mutex_unlock(&class_mutex);
}

void process_save_to_text(RequestData *req, ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    int result = save_to_text_file(&global_class, req->filename);
    resp->success = (result == 0);
    strcpy(resp->message, result == 0 ? "保存到文本文件成功" : "保存失败");
    
    pthread_mutex_unlock(&class_mutex);
}

void process_load_from_text(RequestData *req, ResponseData *resp) {
    pthread_mutex_lock(&class_mutex);
    
    int result = load_from_text_file(&global_class, req->filename);
    resp->success = (result == 0);
    strcpy(resp->message, result == 0 ? "从文本文件加载成功" : "加载失败");
    
    pthread_mutex_unlock(&class_mutex);
}

// 修改线程处理函数
void* client_handler(void* arg) {
    int client_socket = *((int*)arg);
    free(arg); // 释放分配的内存
    
    Message msg;
    int bytes_received;
    
    printf("客户端连接成功\n");
    
    while ((bytes_received = recv(client_socket, &msg, sizeof(Message), 0)) > 0) {
        RequestData req;
        ResponseData resp = {0};
        
        // 反序列化请求数据
        if (msg.data_length > 0) {
            deserialize_request(msg.data, &req);
        }
        
        // 根据消息类型处理请求
        switch (msg.type) {
            case MSG_ADD_STUDENT:
                process_add_student(&req, &resp);
                break;
            case MSG_SEARCH_BY_NAME:
                process_search_by_name(&req, &resp);
                break;
            case MSG_SEARCH_BY_ID:
                process_search_by_id(&req, &resp);
                break;
            case MSG_CALC_STUDENT_STATS:
                process_calc_student_stats(&resp);
                break;
            case MSG_CALC_CLASS_STATS:
                process_calc_class_stats(&resp);
                break;
            case MSG_DISPLAY_ALL:
                process_display_all(&resp);
                break;
            case MSG_SAVE_TO_TEXT:
                process_save_to_text(&req, &resp);
                break;
            case MSG_LOAD_FROM_TEXT:
                process_load_from_text(&req, &resp);
                break;
            case MSG_EXIT:
                resp.success = 1;
                strcpy(resp.message, "再见");
                break;
            default:
                resp.success = 0;
                strcpy(resp.message, "未知操作");
        }
        
        // 发送响应
        char buffer[BUFFER_SIZE];
        int length = serialize_response(&resp, buffer);
        
        Message response_msg;
        response_msg.type = resp.success ? MSG_RESPONSE_SUCCESS : MSG_RESPONSE_ERROR;
        response_msg.data_length = length;
        memcpy(response_msg.data, buffer, length);
        
        send(client_socket, &response_msg, sizeof(Message), 0);
        
        if (msg.type == MSG_EXIT) break;
    }
    
    close(client_socket);
    printf("客户端断开连接\n");
    return NULL;
}

// 序列化请求
int serialize_request(RequestData *req, char *buffer) {
    memcpy(buffer, req, sizeof(RequestData));
    return sizeof(RequestData);
}

// 反序列化请求
int deserialize_request(char *buffer, RequestData *req) {
    memcpy(req, buffer, sizeof(RequestData));
    return sizeof(RequestData);
}

// 序列化响应
int serialize_response(ResponseData *resp, char *buffer) {
    memcpy(buffer, resp, sizeof(ResponseData));
    return sizeof(ResponseData);
}

// 反序列化响应
int deserialize_response(char *buffer, ResponseData *resp) {
    memcpy(resp, buffer, sizeof(ResponseData));
    return sizeof(ResponseData);
}



int main() {
    int server_socket; // 移除 client_socket，因为未使用
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    init_server();
    
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    
    int opt = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
    
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }
    
    if (listen(server_socket, MAX_CLIENTS) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }
    
    printf("成绩管理系统服务器启动，监听端口 %d...\n", PORT);
    
    while (1) {
        int *client_socket = malloc(sizeof(int));
        *client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
        if (*client_socket < 0) {
            perror("Accept failed");
            free(client_socket);
            continue;
        }
        
        printf("新的客户端连接: %s:%d\n", 
            inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
        
        pthread_t thread_id;
        if (pthread_create(&thread_id, NULL, client_handler, client_socket) != 0) {
            perror("Thread creation failed");
            close(*client_socket);
            free(client_socket);
    }
    
    pthread_detach(thread_id);
    }
    
    close(server_socket);
    return 0;
}