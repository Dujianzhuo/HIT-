#ifndef PROTOCOL_H
#define PROTOCOL_H

#include "student.h"

// 消息类型
typedef enum {
    MSG_ADD_STUDENT = 1,
    MSG_SEARCH_BY_NAME,
    MSG_SEARCH_BY_ID,
    MSG_MODIFY_STUDENT,
    MSG_DELETE_STUDENT,
    MSG_CALC_STUDENT_STATS,
    MSG_CALC_CLASS_STATS,
    MSG_SORT_BY_COURSE,
    MSG_STATISTIC_ANALYSIS,
    MSG_SAVE_TO_TEXT,
    MSG_LOAD_FROM_TEXT,
    MSG_SAVE_TO_BINARY,
    MSG_LOAD_FROM_BINARY,
    MSG_DISPLAY_ALL,
    MSG_RESPONSE_SUCCESS,
    MSG_RESPONSE_ERROR,
    MSG_EXIT
} MessageType;

// 请求数据结构
typedef struct {
    char search_key[32];
    int course_choice;
    int student_index;
    STUDENT student;
    char filename[256];
} RequestData;

// 响应数据结构
typedef struct {
    int success;
    char message[512];
    STUDENT student;
    CLASS class_data;
} ResponseData;

// 消息结构
typedef struct {
    MessageType type;
    int data_length;
    char data[2048];
} Message;

#endif