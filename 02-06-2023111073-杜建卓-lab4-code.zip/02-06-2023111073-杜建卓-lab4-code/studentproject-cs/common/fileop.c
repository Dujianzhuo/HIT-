#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fileop.h"
#include "student.h"

int save_to_text_file(CLASS *class, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("无法打开文件");
        return -1;
    }

    fprintf(file, "学号,姓名,计算机系统,程序设计实践,数据结构,数字逻辑\n");
    for (int i = 0; i < class->count; i++) {
        STUDENT *s = &class->students[i];
        fprintf(file, "%s,%s,%.1f,%.1f,%.1f,%.1f\n",
                s->stu_id, s->stu_name, s->score.ics, s->score.pdp,
                s->score.ds, s->score.dl);
    }

    fclose(file);
    printf("数据已保存到文本文件: %s\n", filename);
    return 0;
}

int load_from_text_file(CLASS *class, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("无法打开文件");
        return -1;
    }

    char line[256];
    fgets(line, sizeof(line), file); // 跳过标题行

    class->count = 0;
    while (fgets(line, sizeof(line), file) && class->count < MAX_STUDENTS) {
        STUDENT *s = &class->students[class->count];
        char *token = strtok(line, ",");
        if (token) strcpy(s->stu_id, token);
        
        token = strtok(NULL, ",");
        if (token) strcpy(s->stu_name, token);
        
        token = strtok(NULL, ",");
        if (token) s->score.ics = atof(token);
        
        token = strtok(NULL, ",");
        if (token) s->score.pdp = atof(token);
        
        token = strtok(NULL, ",");
        if (token) s->score.ds = atof(token);
        
        token = strtok(NULL, ",");
        if (token) s->score.dl = atof(token);

        s->total = s->score.ics + s->score.pdp + s->score.ds + s->score.dl;
        s->average = s->total / 4.0f;
        
        class->count++;
    }

    fclose(file);
    printf("从文本文件加载数据成功: %s\n", filename);
    return 0;
}

int save_to_binary_file(CLASS *class, const char *filename) {
    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
        perror("无法打开文件");
        return -1;
    }

    fwrite(&class->count, sizeof(int), 1, file);
    fwrite(class->students, sizeof(STUDENT), class->count, file);

    fclose(file);
    printf("数据已保存到二进制文件: %s\n", filename);
    return 0;
}

int load_from_binary_file(CLASS *class, const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        perror("无法打开文件");
        return -1;
    }

    fread(&class->count, sizeof(int), 1, file);
    fread(class->students, sizeof(STUDENT), class->count, file);

    fclose(file);
    printf("从二进制文件加载数据成功: %s\n", filename);
    return 0;
}