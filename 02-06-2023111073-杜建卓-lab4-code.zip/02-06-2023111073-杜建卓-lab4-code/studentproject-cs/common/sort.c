#include "sort.h"
#include <string.h>

void bubble_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (compare(&arr[j], &arr[j + 1]) < 0) {
                STUDENT temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void bubble_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (compare(&arr[j], &arr[j + 1]) > 0) {
                STUDENT temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int compare_ics(const STUDENT *a, const STUDENT *b) {
    if (a->score.ics > b->score.ics) return 1;
    if (a->score.ics < b->score.ics) return -1;
    return 0;
}

int compare_pdp(const STUDENT *a, const STUDENT *b) {
    if (a->score.pdp > b->score.pdp) return 1;
    if (a->score.pdp < b->score.pdp) return -1;
    return 0;
}

int compare_ds(const STUDENT *a, const STUDENT *b) {
    if (a->score.ds > b->score.ds) return 1;
    if (a->score.ds < b->score.ds) return -1;
    return 0;
}

int compare_dl(const STUDENT *a, const STUDENT *b) {
    if (a->score.dl > b->score.dl) return 1;
    if (a->score.dl < b->score.dl) return -1;
    return 0;
}

int compare_total(const STUDENT *a, const STUDENT *b) {
    if (a->total > b->total) return 1;
    if (a->total < b->total) return -1;
    return 0;
}