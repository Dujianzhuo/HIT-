#ifndef SORT_H
#define SORT_H

#include "student.h"

void bubble_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
void bubble_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
int compare_ics(const STUDENT *a, const STUDENT *b);
int compare_pdp(const STUDENT *a, const STUDENT *b);
int compare_ds(const STUDENT *a, const STUDENT *b);
int compare_dl(const STUDENT *a, const STUDENT *b);
int compare_total(const STUDENT *a, const STUDENT *b);

#endif