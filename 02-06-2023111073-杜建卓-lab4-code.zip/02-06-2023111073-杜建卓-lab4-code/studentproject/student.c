#include <stdio.h>
#include <string.h>
#include "student.h"

void init_class(CLASS *class) {
    class->count = 0;
    class->ics_avg = class->pdp_avg = class->ds_avg = class->dl_avg = 0.0f;
}

int add_student(CLASS *class) {
    if (class->count >= MAX_STUDENTS) {
        printf("班级已满，无法添加更多学生！\n");
        return -1;
    }

    STUDENT *s = &class->students[class->count];
    
    printf("请输入学号: ");
    scanf("%s", s->stu_id);
    printf("请输入姓名: ");
    scanf("%s", s->stu_name);
    printf("请输入计算机系统成绩: ");
    scanf("%f", &s->score.ics);
    printf("请输入程序设计实践成绩: ");
    scanf("%f", &s->score.pdp);
    printf("请输入数据结构成绩: ");
    scanf("%f", &s->score.ds);
    printf("请输入数字逻辑成绩: ");
    scanf("%f", &s->score.dl);

    // 计算总分和平均分
    s->total = s->score.ics + s->score.pdp + s->score.ds + s->score.dl;
    s->average = s->total / 4.0f;

    class->count++;
    printf("学生信息添加成功！\n");
    return 0;
}

int search_by_name(CLASS *class, const char *name) {
    for (int i = 0; i < class->count; i++) {
        if (strcmp(class->students[i].stu_name, name) == 0) {
            return i;
        }
    }
    return -1;
}

int search_by_id(CLASS *class, const char *id) {
    for (int i = 0; i < class->count; i++) {
        if (strcmp(class->students[i].stu_id, id) == 0) {
            return i;
        }
    }
    return -1;
}

void modify_student(CLASS *class, int index) {
    if (index < 0 || index >= class->count) {
        printf("无效的学生索引！\n");
        return;
    }

    STUDENT *s = &class->students[index];
    printf("修改学生信息 (直接回车保持原值):\n");
    
    printf("姓名 (%s): ", s->stu_name);
    char temp[NAME_LENGTH];
    getchar(); // 清除缓冲区
    fgets(temp, NAME_LENGTH, stdin);
    if (strlen(temp) > 1) {
        temp[strcspn(temp, "\n")] = 0;
        strcpy(s->stu_name, temp);
    }

    printf("计算机系统成绩 (%.2f): ", s->score.ics);
    fgets(temp, NAME_LENGTH, stdin);
    if (strlen(temp) > 1) {
        sscanf(temp, "%f", &s->score.ics);
    }

    printf("程序设计实践成绩 (%.2f): ", s->score.pdp);
    fgets(temp, NAME_LENGTH, stdin);
    if (strlen(temp) > 1) {
        sscanf(temp, "%f", &s->score.pdp);
    }

    printf("数据结构成绩 (%.2f): ", s->score.ds);
    fgets(temp, NAME_LENGTH, stdin);
    if (strlen(temp) > 1) {
        sscanf(temp, "%f", &s->score.ds);
    }

    printf("数字逻辑成绩 (%.2f): ", s->score.dl);
    fgets(temp, NAME_LENGTH, stdin);
    if (strlen(temp) > 1) {
        sscanf(temp, "%f", &s->score.dl);
    }

    // 重新计算总分和平均分
    s->total = s->score.ics + s->score.pdp + s->score.ds + s->score.dl;
    s->average = s->total / 4.0f;

    printf("学生信息修改成功！\n");
}

void delete_student(CLASS *class, int index) {
    if (index < 0 || index >= class->count) {
        printf("无效的学生索引！\n");
        return;
    }

    for (int i = index; i < class->count - 1; i++) {
        class->students[i] = class->students[i + 1];
    }
    class->count--;
    printf("学生信息删除成功！\n");
}

void calculate_student_stats(CLASS *class) {
    printf("\n%-15s %-15s %-8s %-8s %-8s %-8s %-8s %-8s\n", 
           "学号", "姓名", "ICS", "PDP", "DS", "DL", "总分", "平均分");
    printf("------------------------------------------------------------------------\n");
    
    for (int i = 0; i < class->count; i++) {
        STUDENT *s = &class->students[i];
        printf("%-15s %-15s %-8.1f %-8.1f %-8.1f %-8.1f %-8.1f %-8.1f\n",
               s->stu_id, s->stu_name, s->score.ics, s->score.pdp,
               s->score.ds, s->score.dl, s->total, s->average);
    }
}

void calculate_class_stats(CLASS *class) {
    float ics_sum = 0, pdp_sum = 0, ds_sum = 0, dl_sum = 0;
    
    for (int i = 0; i < class->count; i++) {
        ics_sum += class->students[i].score.ics;
        pdp_sum += class->students[i].score.pdp;
        ds_sum += class->students[i].score.ds;
        dl_sum += class->students[i].score.dl;
    }
    
    class->ics_avg = ics_sum / class->count;
    class->pdp_avg = pdp_sum / class->count;
    class->ds_avg = ds_sum / class->count;
    class->dl_avg = dl_sum / class->count;
    
    printf("\n班级各科平均成绩:\n");
    printf("计算机系统: %.2f\n", class->ics_avg);
    printf("程序设计实践: %.2f\n", class->pdp_avg);
    printf("数据结构: %.2f\n", class->ds_avg);
    printf("数字逻辑: %.2f\n", class->dl_avg);
}

void display_student(STUDENT *student) {
    printf("\n学生信息:\n");
    printf("学号: %s\n", student->stu_id);
    printf("姓名: %s\n", student->stu_name);
    printf("计算机系统: %.2f\n", student->score.ics);
    printf("程序设计实践: %.2f\n", student->score.pdp);
    printf("数据结构: %.2f\n", student->score.ds);
    printf("数字逻辑: %.2f\n", student->score.dl);
    printf("总分: %.2f\n", student->total);
    printf("平均分: %.2f\n", student->average);
}

void display_all_students(CLASS *class) {
    printf("\n%-15s %-15s %-8s %-8s %-8s %-8s\n", 
           "学号", "姓名", "ICS", "PDP", "DS", "DL");
    printf("------------------------------------------------\n");
    
    for (int i = 0; i < class->count; i++) {
        STUDENT *s = &class->students[i];
        printf("%-15s %-15s %-8.2f %-8.2f %-8.2f %-8.2f\n",
               s->stu_id, s->stu_name, s->score.ics, s->score.pdp,
               s->score.ds, s->score.dl);
    }
}