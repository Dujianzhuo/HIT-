#ifndef SORT_H
#define SORT_H

#include "student.h"

void bubble_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
void bubble_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));

// 快速排序
void quick_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
void quick_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));

// 插入排序
void insertion_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
void insertion_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));

// 归并排序
void merge_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
void merge_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));

// 堆排序
void heap_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
void heap_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));

// 选择排序
void selection_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));
void selection_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *));

int compare_ics(const STUDENT *a, const STUDENT *b);
int compare_pdp(const STUDENT *a, const STUDENT *b);
int compare_ds(const STUDENT *a, const STUDENT *b);
int compare_dl(const STUDENT *a, const STUDENT *b);
int compare_total(const STUDENT *a, const STUDENT *b);

#endif