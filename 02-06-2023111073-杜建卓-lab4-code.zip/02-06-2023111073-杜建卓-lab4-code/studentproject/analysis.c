#include <stdio.h>
#include "student.h"
#include "analysis.h"

void statistic_analysis(CLASS *class, int course_choice) {
    int levels[5] = {0}; // 优秀,良好,中等,及格,不及格
    const char *level_names[] = {"优秀(90-100)", "良好(80-89)", "中等(70-79)", "及格(60-69)", "不及格(0-59)"};
    const char *course_names[] = {"计算机系统", "程序设计实践", "数据结构", "数字逻辑"};
    
    for (int i = 0; i < class->count; i++) {
        float score;
        switch (course_choice) {
            case 1: score = class->students[i].score.ics; break;
            case 2: score = class->students[i].score.pdp; break;
            case 3: score = class->students[i].score.ds; break;
            case 4: score = class->students[i].score.dl; break;
            default: return;
        }
        
        if (score >= 90) levels[0]++;
        else if (score >= 80) levels[1]++;
        else if (score >= 70) levels[2]++;
        else if (score >= 60) levels[3]++;
        else levels[4]++;
    }
    
    printf("\n%s成绩统计分析:\n", course_names[course_choice - 1]);
    printf("%-20s %-10s %-10s\n", "等级", "人数", "百分比");
    printf("----------------------------------------\n");
    
    for (int i = 0; i < 5; i++) {
        float percentage = (float)levels[i] / class->count * 100;
        printf("%-20s %-10d %-10.1f%%\n", level_names[i], levels[i], percentage);
    }
}