#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
#include "fileop.h"
#include "sort.h"
#include "analysis.h"

void display_menu() {
    printf("\n========== 成绩管理系统 ==========\n");
    printf("1. 添加学生记录\n");
    printf("2. 按姓名查询\n");
    printf("3. 按学号查询\n");
    printf("4. 修改学生信息\n");
    printf("5. 删除学生信息\n");
    printf("6. 计算学生总分和平均分\n");
    printf("7. 计算班级平均分\n");
    printf("8. 按课程成绩排序\n");
    printf("9. 成绩统计分析\n");
    printf("10. 保存到文本文件\n");
    printf("11. 从文本文件加载\n");
    printf("12. 保存到二进制文件\n");
    printf("13. 从二进制文件加载\n");
    printf("14. 显示所有学生\n");
    printf("0. 退出\n");
    printf("==================================\n");
    printf("请选择操作: ");
}

int main() {
    CLASS my_class;
    init_class(&my_class);
    int choice;
    
    do {
        display_menu();
        scanf("%d", &choice);
        
        switch (choice) {
            case 1: // 添加学生
                add_student(&my_class);
                break;
                
            case 2: { // 按姓名查询
                char name[NAME_LENGTH];
                printf("请输入要查询的姓名: ");
                scanf("%s", name);
                int index = search_by_name(&my_class, name);
                if (index != -1) {
                    display_student(&my_class.students[index]);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
                
            case 3: { // 按学号查询
                char id[ID_LENGTH];
                printf("请输入要查询的学号: ");
                scanf("%s", id);
                int index = search_by_id(&my_class, id);
                if (index != -1) {
                    display_student(&my_class.students[index]);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
                
            case 4: { // 修改学生信息
                char id[ID_LENGTH];
                printf("请输入要修改的学生学号: ");
                scanf("%s", id);
                int index = search_by_id(&my_class, id);
                if (index != -1) {
                    modify_student(&my_class, index);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
                
            case 5: { // 删除学生信息
                char id[ID_LENGTH];
                printf("请输入要删除的学生学号: ");
                scanf("%s", id);
                int index = search_by_id(&my_class, id);
                if (index != -1) {
                    delete_student(&my_class, index);
                } else {
                    printf("未找到该学生！\n");
                }
                break;
            }
                
            case 6: // 计算学生总分和平均分
                calculate_student_stats(&my_class);
                break;
                
            case 7: // 计算班级平均分
                calculate_class_stats(&my_class);
                break;
                
            case 8: { // 按课程成绩排序
                printf("请选择排序的课程:\n");
                printf("1. 计算机系统\n2. 程序设计实践\n3. 数据结构\n4. 数字逻辑\n5. 总分\n");
                int course_choice;
                scanf("%d", &course_choice);

                printf("请选择排序方式:\n");
                printf("1. 升序\n2. 降序\n");
                int order_choice;
                scanf("%d", &order_choice);
                
                int (*compare_func)(const STUDENT *, const STUDENT *) = NULL;
                switch (course_choice) {
                    case 1: compare_func = compare_ics; break;
                    case 2: compare_func = compare_pdp; break;
                    case 3: compare_func = compare_ds; break;
                    case 4: compare_func = compare_dl; break;
                    case 5: compare_func = compare_total; break;
                    default: printf("无效选择！\n"); break;
                }
                
                if (compare_func) {
                    if (order_choice == 1) {
                        // 升序排序
                        bubble_sort_up(my_class.students, my_class.count, compare_func);
                    } else {
                        // 降序排序
                        bubble_sort_down(my_class.students, my_class.count, compare_func);
                    }
                    printf("排序完成！\n");
                    display_all_students(&my_class);
                }
                break;
            }
                
            case 9: { // 成绩统计分析
                printf("请选择分析的课程:\n");
                printf("1. 计算机系统\n2. 程序设计实践\n3. 数据结构\n4. 数字逻辑\n");
                int course_choice;
                scanf("%d", &course_choice);
                
                if (course_choice >= 1 && course_choice <= 4) {
                    statistic_analysis(&my_class, course_choice);
                } else {
                    printf("无效选择！\n");
                }
                break;
            }
                
            case 10: // 保存到文本文件
                save_to_text_file(&my_class, "students.txt");
                break;
                
            case 11: // 从文本文件加载
                load_from_text_file(&my_class, "students.txt");
                break;
                
            case 12: // 保存到二进制文件
                save_to_binary_file(&my_class, "students.dat");
                break;
                
            case 13: // 从二进制文件加载
                load_from_binary_file(&my_class, "students.dat");
                break;
                
            case 14: // 显示所有学生
                display_all_students(&my_class);
                break;
                
            case 0: // 退出
                printf("感谢使用成绩管理系统！\n");
                break;
                
            default:
                printf("无效的选择，请重新输入！\n");
        }
        
        printf("\n按回车键继续...");
        getchar(); getchar(); // 等待用户按回车
        
    } while (choice != 0);
    
    return 0;
}