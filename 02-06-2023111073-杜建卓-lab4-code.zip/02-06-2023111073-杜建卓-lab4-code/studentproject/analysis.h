#ifndef ANALYSIS_H
#define ANALYSIS_H

#include "student.h"

void statistic_analysis(CLASS *class, int course_choice);

#endif