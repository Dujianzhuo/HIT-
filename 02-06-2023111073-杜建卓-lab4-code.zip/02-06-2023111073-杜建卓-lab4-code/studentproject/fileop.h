#ifndef FILEOP_H
#define FILEOP_H

#include "student.h"

int save_to_text_file(CLASS *class, const char *filename);
int load_from_text_file(CLASS *class, const char *filename);
int save_to_binary_file(CLASS *class, const char *filename);
int load_from_binary_file(CLASS *class, const char *filename);

#endif