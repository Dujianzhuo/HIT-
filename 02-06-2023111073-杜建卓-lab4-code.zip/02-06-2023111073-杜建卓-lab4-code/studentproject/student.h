#ifndef STUDENT_H
#define STUDENT_H

#define MAX_STUDENTS 45
#define NAME_LENGTH 32
#define ID_LENGTH 32

typedef struct course {
    float ics;
    float pdp;
    float ds;
    float dl;
} COURSE;

typedef struct student {
    char stu_id[ID_LENGTH];
    char stu_name[NAME_LENGTH];
    COURSE score;
    float total;
    float average;
} STUDENT;

typedef struct class_info {
    STUDENT students[MAX_STUDENTS];
    int count;
    float ics_avg;
    float pdp_avg;
    float ds_avg;
    float dl_avg;
} CLASS;

// 函数声明
void init_class(CLASS *class);
int add_student(CLASS *class);
int search_by_name(CLASS *class, const char *name);
int search_by_id(CLASS *class, const char *id);
void modify_student(CLASS *class, int index);
void delete_student(CLASS *class, int index);
void calculate_student_stats(CLASS *class);
void calculate_class_stats(CLASS *class);
void sort_by_course(CLASS *class, int course_choice);
void statistic_analysis(CLASS *class, int course_choice);
void display_student(STUDENT *student);
void display_all_students(CLASS *class);

#endif