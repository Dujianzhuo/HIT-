#include "sort.h"
#include <string.h>

void bubble_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (compare(&arr[j], &arr[j + 1]) < 0) {
                STUDENT temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void bubble_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (compare(&arr[j], &arr[j + 1]) > 0) {
                STUDENT temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// 快速排序
void quick_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    if (n <= 1) return;
    
    STUDENT pivot = arr[n - 1];
    int i = -1;
    
    for (int j = 0; j < n - 1; j++) {
        if (compare(&arr[j], &pivot) > 0) {
            i++;
            STUDENT temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    
    STUDENT temp = arr[i + 1];
    arr[i + 1] = arr[n - 1];
    arr[n - 1] = temp;
    
    quick_sort_down(arr, i + 1, compare);
    quick_sort_down(arr + i + 2, n - i - 2, compare);
}

void quick_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    if (n <= 1) return;
    
    STUDENT pivot = arr[n - 1];
    int i = -1;
    
    for (int j = 0; j < n - 1; j++) {
        if (compare(&arr[j], &pivot) < 0) {
            i++;
            STUDENT temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    
    STUDENT temp = arr[i + 1];
    arr[i + 1] = arr[n - 1];
    arr[n - 1] = temp;
    
    quick_sort_up(arr, i + 1, compare);
    quick_sort_up(arr + i + 2, n - i - 2, compare);
}

// 插入排序
void insertion_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 1; i < n; i++) {
        STUDENT key = arr[i];
        int j = i - 1;
        
        while (j >= 0 && compare(&arr[j], &key) < 0) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

void insertion_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 1; i < n; i++) {
        STUDENT key = arr[i];
        int j = i - 1;
        
        while (j >= 0 && compare(&arr[j], &key) > 0) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// 归并排序辅助函数
void merge_down(STUDENT arr[], int l, int m, int r, int (*compare)(const STUDENT *, const STUDENT *)) {
    int n1 = m - l + 1;
    int n2 = r - m;
    
    STUDENT L[n1], R[n2];
    
    for (int i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (int j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];
    
    int i = 0, j = 0, k = l;
    
    while (i < n1 && j < n2) {
        if (compare(&L[i], &R[j]) >= 0) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
    
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void merge_up(STUDENT arr[], int l, int m, int r, int (*compare)(const STUDENT *, const STUDENT *)) {
    int n1 = m - l + 1;
    int n2 = r - m;
    
    STUDENT L[n1], R[n2];
    
    for (int i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (int j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];
    
    int i = 0, j = 0, k = l;
    
    while (i < n1 && j < n2) {
        if (compare(&L[i], &R[j]) <= 0) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
    
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void merge_sort_recursive_down(STUDENT arr[], int l, int r, int (*compare)(const STUDENT *, const STUDENT *)) {
    if (l < r) {
        int m = l + (r - l) / 2;
        merge_sort_recursive_down(arr, l, m, compare);
        merge_sort_recursive_down(arr, m + 1, r, compare);
        merge_down(arr, l, m, r, compare);
    }
}

void merge_sort_recursive_up(STUDENT arr[], int l, int r, int (*compare)(const STUDENT *, const STUDENT *)) {
    if (l < r) {
        int m = l + (r - l) / 2;
        merge_sort_recursive_up(arr, l, m, compare);
        merge_sort_recursive_up(arr, m + 1, r, compare);
        merge_up(arr, l, m, r, compare);
    }
}

void merge_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    merge_sort_recursive_down(arr, 0, n - 1, compare);
}

void merge_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    merge_sort_recursive_up(arr, 0, n - 1, compare);
}

// 堆排序辅助函数
void heapify_down(STUDENT arr[], int n, int i, int (*compare)(const STUDENT *, const STUDENT *)) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    
    if (left < n && compare(&arr[left], &arr[largest]) > 0)
        largest = left;
    
    if (right < n && compare(&arr[right], &arr[largest]) > 0)
        largest = right;
    
    if (largest != i) {
        STUDENT temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;
        heapify_down(arr, n, largest, compare);
    }
}

void heapify_up(STUDENT arr[], int n, int i, int (*compare)(const STUDENT *, const STUDENT *)) {
    int smallest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    
    if (left < n && compare(&arr[left], &arr[smallest]) < 0)
        smallest = left;
    
    if (right < n && compare(&arr[right], &arr[smallest]) < 0)
        smallest = right;
    
    if (smallest != i) {
        STUDENT temp = arr[i];
        arr[i] = arr[smallest];
        arr[smallest] = temp;
        heapify_up(arr, n, smallest, compare);
    }
}

void heap_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify_down(arr, n, i, compare);
    
    for (int i = n - 1; i > 0; i--) {
        STUDENT temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        heapify_down(arr, i, 0, compare);
    }
}

void heap_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify_up(arr, n, i, compare);
    
    for (int i = n - 1; i > 0; i--) {
        STUDENT temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        heapify_up(arr, i, 0, compare);
    }
}

// 选择排序
void selection_sort_down(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 0; i < n - 1; i++) {
        int max_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (compare(&arr[j], &arr[max_idx]) > 0) {
                max_idx = j;
            }
        }
        STUDENT temp = arr[i];
        arr[i] = arr[max_idx];
        arr[max_idx] = temp;
    }
}

void selection_sort_up(STUDENT arr[], int n, int (*compare)(const STUDENT *, const STUDENT *)) {
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (compare(&arr[j], &arr[min_idx]) < 0) {
                min_idx = j;
            }
        }
        STUDENT temp = arr[i];
        arr[i] = arr[min_idx];
        arr[min_idx] = temp;
    }
}

int compare_ics(const STUDENT *a, const STUDENT *b) {
    if (a->score.ics > b->score.ics) return 1;
    if (a->score.ics < b->score.ics) return -1;
    return 0;
}

int compare_pdp(const STUDENT *a, const STUDENT *b) {
    if (a->score.pdp > b->score.pdp) return 1;
    if (a->score.pdp < b->score.pdp) return -1;
    return 0;
}

int compare_ds(const STUDENT *a, const STUDENT *b) {
    if (a->score.ds > b->score.ds) return 1;
    if (a->score.ds < b->score.ds) return -1;
    return 0;
}

int compare_dl(const STUDENT *a, const STUDENT *b) {
    if (a->score.dl > b->score.dl) return 1;
    if (a->score.dl < b->score.dl) return -1;
    return 0;
}

int compare_total(const STUDENT *a, const STUDENT *b) {
    if (a->total > b->total) return 1;
    if (a->total < b->total) return -1;
    return 0;
}