#include "sort.h"
#include <sys/time.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>  // 添加 isalpha() 函数需要的头文件
#include <stdlib.h>  // 添加 malloc、free 等函数需要的头文件

// 测试函数声明
void test_int_sort(int size);
void test_float_sort(int size);
void test_struct_sort(int size);
double get_time();

// 文件操作函数
void write_int_array_to_file(const char *filename, int *arr, int size);
void write_float_array_to_file(const char *filename, float *arr, int size);
void write_student_array_to_file(const char *filename, Student *arr, int size);

int read_int_from_file(const char *filename, int **arr);
int read_float_from_file(const char *filename, float **arr);
int read_student_from_file(const char *filename, Student **arr);
int detect_file_type(const char *filename);
void sort_from_file(const char *filename);
void print_usage();

int main(int argc, char *argv[]) {
    if (argc < 2) {
        print_usage();
        return 1;
    }
    
    int mode = atoi(argv[1]);
    
    if (mode == 1) {
        // 从文件排序模式
        if (argc != 3) {
            printf("错误：文件模式需要指定文件名\n");
            printf("用法: %s 1 <文件名>\n", argv[0]);
            return 1;
        }
        sort_from_file(argv[2]);
    }
    else if (mode == 2) {
        // 随机生成数据排序模式
        if (argc != 3) {
            printf("错误：随机模式需要指定数据规模\n");
            printf("用法: %s 2 <数据规模>\n", argv[0]);
            return 1;
        }
        
        int size = atoi(argv[2]);
        if (size <= 0) {
            printf("错误：数据规模必须大于0\n");
            return 1;
        }
        
        printf("Testing with array size: %d\n", size);
        printf("========================================\n");
        
        // 测试整型排序
        test_int_sort(size);
        printf("\n");
        
        // 测试浮点数排序
        test_float_sort(size);
        printf("\n");
        
        // 测试结构体排序
        test_struct_sort(size);
    }
    else {
        print_usage();
        return 1;
    }
    
    return 0;
}

void print_usage() {
    // printf("用法:\n");
    // printf("  从文件排序: %s 1 <文件名>\n", argv[0]);
    // printf("  随机生成数据: %s 2 <数据规模>\n", argv[0]);
    // printf("示例:\n");
    // printf("  %s 1 test.txt\n", argv[0]);
    // printf("  %s 2 1000\n", argv[0]);
}

int detect_file_type(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("错误：无法打开文件 %s\n", filename);
        return -1;
    }
    
    char line[256];
    int line_count = 0;
    int has_comma = 0;
    int has_header = 0;
    
    // 读取前几行来分析文件类型
    while (fgets(line, sizeof(line), file) && line_count < 5) {
        line_count++;
        
        // 检查是否包含逗号（可能是CSV格式）
        if (strchr(line, ',') != NULL) {
            has_comma = 1;
        }
        
        // 检查是否有表头（包含ID,Name,Score等字段）
        if (strstr(line, "ID") != NULL || strstr(line, "Name") != NULL || strstr(line, "Score") != NULL) {
            has_header = 1;
        }
        
        // 检查是否包含字母（可能是结构体）
        for (int i = 0; line[i] != '\0'; i++) {
            if (isalpha(line[i]) && !has_comma) {
                has_comma = 1; // 标记为可能需要特殊处理
            }
        }
    }
    
    fclose(file);
    
    if (has_comma && has_header) {
        return 3; // 结构体文件（CSV格式）
    } else if (has_comma) {
        return 2; // 可能是浮点数或其他格式
    } else {
        return 1; // 整型文件
    }
}

int read_int_from_file(const char *filename, int **arr) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return -1;
    }
    
    int count = 0;
    int value;
    int capacity = 100;
    *arr = (int *)malloc(capacity * sizeof(int));
    
    while (fscanf(file, "%d", &value) == 1) {
        if (count >= capacity) {
            capacity *= 2;
            *arr = (int *)realloc(*arr, capacity * sizeof(int));
        }
        (*arr)[count++] = value;
    }
    
    fclose(file);
    return count;
}

int read_float_from_file(const char *filename, float **arr) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return -1;
    }
    
    int count = 0;
    float value;
    int capacity = 100;
    *arr = (float *)malloc(capacity * sizeof(float));
    
    while (fscanf(file, "%f", &value) == 1) {
        if (count >= capacity) {
            capacity *= 2;
            *arr = (float *)realloc(*arr, capacity * sizeof(float));
        }
        (*arr)[count++] = value;
    }
    
    fclose(file);
    return count;
}

int read_student_from_file(const char *filename, Student **arr) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return -1;
    }
    
    int count = 0;
    int capacity = 100;
    char line[256];
    *arr = (Student *)malloc(capacity * sizeof(Student));
    
    // 跳过可能的表头
    if (fgets(line, sizeof(line), file) == NULL) {
        fclose(file);
        free(*arr);
        return 0;
    }
    
    if (strstr(line, "ID") != NULL && strstr(line, "Name") != NULL && strstr(line, "Score") != NULL) {
        // 这是表头，跳过
    } else {
        // 不是表头，回退到文件开头
        fseek(file, 0, SEEK_SET);
    }
    
    while (fgets(line, sizeof(line), file)) {
        if (count >= capacity) {
            capacity *= 2;
            *arr = (Student *)realloc(*arr, capacity * sizeof(Student));
        }
        
        Student student;
        if (sscanf(line, "%d,%[^,],%f", &student.id, student.name, &student.score) == 3) {
            (*arr)[count++] = student;
        }
    }
    
    fclose(file);
    return count;
}

void sort_from_file(const char *filename) {
    int file_type = detect_file_type(filename);
    
    if (file_type == 1) {
        // 整型文件
        int *arr;
        int size = read_int_from_file(filename, &arr);
        
        if (size <= 0) {
            printf("错误：无法读取整型数据或文件为空\n");
            return;
        }
        
        printf("检测到整型数据，数据量: %d\n", size);
        printf("开始排序...\n");
        
        int *temp = (int *)malloc(size * sizeof(int));
        memcpy(temp, arr, size * sizeof(int));
        
        double start = get_time();
        quick_sort(temp, size, sizeof(int), compare_int);
        double end = get_time();
        
        printf("快速排序完成: %.6f 秒\n", end - start);
        verify_sorted(temp, size, sizeof(int), compare_int);
        
        // 写入排序结果
        write_int_array_to_file("test.txt", temp, size);
        
        free(arr);
        free(temp);
    }
    else if (file_type == 2) {
        // 浮点数文件
        float *arr;
        int size = read_float_from_file(filename, &arr);
        
        if (size <= 0) {
            printf("错误：无法读取浮点数数据或文件为空\n");
            return;
        }
        
        printf("检测到浮点数数据，数据量: %d\n", size);
        printf("开始排序...\n");
        
        float *temp = (float *)malloc(size * sizeof(float));
        memcpy(temp, arr, size * sizeof(float));
        
        double start = get_time();
        quick_sort(temp, size, sizeof(float), compare_float);
        double end = get_time();
        
        printf("快速排序完成: %.6f 秒\n", end - start);
        verify_sorted(temp, size, sizeof(float), compare_float);
        
        // 写入排序结果
        write_float_array_to_file("file_sort_result.txt", temp, size);
        
        free(arr);
        free(temp);
    }
    else if (file_type == 3) {
        // 结构体文件
        Student *arr;
        int size = read_student_from_file(filename, &arr);
        
        if (size <= 0) {
            printf("错误：无法读取结构体数据或文件为空\n");
            return;
        }
        
        printf("检测到结构体数据，数据量: %d\n", size);
        printf("开始排序...\n");
        
        Student *temp = (Student *)malloc(size * sizeof(Student));
        memcpy(temp, arr, size * sizeof(Student));
        
        double start = get_time();
        quick_sort(temp, size, sizeof(Student), compare_student);
        double end = get_time();
        
        printf("快速排序完成: %.6f 秒\n", end - start);
        verify_sorted(temp, size, sizeof(Student), compare_student);
        
        // 写入排序结果
        write_student_array_to_file("file_sort_result.csv", temp, size);
        
        free(arr);
        free(temp);
    }
    else {
        printf("错误：无法识别的文件格式\n");
    }
}


double get_time() {
    return (double)clock() / CLOCKS_PER_SEC;
}

// 写入整型数组到文件
void write_int_array_to_file(const char *filename, int *arr, int size) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error: Cannot open file %s for writing\n", filename);
        return;
    }
    
    for (int i = 0; i < size; i++) {
        fprintf(file, "%d\n", arr[i]);
    }
    
    fclose(file);
    printf("Data written to %s\n", filename);
}

// 写入浮点数数组到文件
void write_float_array_to_file(const char *filename, float *arr, int size) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error: Cannot open file %s for writing\n", filename);
        return;
    }
    
    for (int i = 0; i < size; i++) {
        fprintf(file, "%.6f\n", arr[i]);
    }
    
    fclose(file);
    printf("Data written to %s\n", filename);
}

// 写入学生数组到文件
void write_student_array_to_file(const char *filename, Student *arr, int size) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error: Cannot open file %s for writing\n", filename);
        return;
    }
    
    // 写入表头
    fprintf(file, "ID,Name,Score\n");
    
    for (int i = 0; i < size; i++) {
        fprintf(file, "%d,%s,%.2f\n", arr[i].id, arr[i].name, arr[i].score);
    }
    
    fclose(file);
    printf("Data written to %s\n", filename);
}

void test_int_sort(int size) {
    printf("Integer Sorting Performance:\n");
    printf("----------------------------\n");
    
    int *arr = (int *)malloc(size * sizeof(int));
    if (arr == NULL) {
        printf("Error: Memory allocation failed for arr\n");
        return;
    }
    
    int *temp = (int *)malloc(size * sizeof(int));
    if (temp == NULL) {
        printf("Error: Memory allocation failed for temp\n");
        free(arr);
        return;
    }
    
    // 生成随机数据
    srand(time(NULL));
    for (int i = 0; i < size; i++) {
        arr[i] = rand() % 1000;
    }
    
    // 将原始随机数据写入文件
    write_int_array_to_file("original_int_data.txt", arr, size);
    
    // 测试选择排序
    memcpy(temp, arr, size * sizeof(int));
    double start = get_time();
    selection_sort(temp, size, sizeof(int), compare_int);
    double end = get_time();
    printf("Selection Sort: %.6f seconds\n", end - start);
    write_int_array_to_file("selection_sort_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(int), compare_int);
    
    // 测试插入排序
    memcpy(temp, arr, size * sizeof(int));
    start = get_time();
    insertion_sort(temp, size, sizeof(int), compare_int);
    end = get_time();
    printf("Insertion Sort: %.6f seconds\n", end - start);
    write_int_array_to_file("insertion_sort_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(int), compare_int);
    
    // 测试冒泡排序
    memcpy(temp, arr, size * sizeof(int));
    start = get_time();
    bubble_sort(temp, size, sizeof(int), compare_int);
    end = get_time();
    printf("Bubble Sort:    %.6f seconds\n", end - start);
    write_int_array_to_file("bubble_sort_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(int), compare_int);
    
    // 测试归并排序
    memcpy(temp, arr, size * sizeof(int));
    start = get_time();
    merge_sort(temp, size, sizeof(int), compare_int);
    end = get_time();
    printf("Merge Sort:     %.6f seconds\n", end - start);
    write_int_array_to_file("merge_sort_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(int), compare_int);
    
    // 测试快速排序
    memcpy(temp, arr, size * sizeof(int));
    start = get_time();
    quick_sort(temp, size, sizeof(int), compare_int);
    end = get_time();
    printf("Quick Sort:     %.6f seconds\n", end - start);
    write_int_array_to_file("quick_sort_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(int), compare_int);
    
    // 测试堆排序
    memcpy(temp, arr, size * sizeof(int));
    start = get_time();
    heap_sort(temp, size, sizeof(int), compare_int);
    end = get_time();
    printf("Heap Sort:      %.6f seconds\n", end - start);
    write_int_array_to_file("heap_sort_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(int), compare_int);
    
    free(arr);
    free(temp);
}

void test_float_sort(int size) {
    printf("Float Sorting Performance:\n");
    printf("--------------------------\n");
    
    float *arr = (float *)malloc(size * sizeof(float));
    if (arr == NULL) {
        printf("Error: Memory allocation failed for arr\n");
        return;
    }
    
    float *temp = (float *)malloc(size * sizeof(float));
    if (temp == NULL) {
        printf("Error: Memory allocation failed for temp\n");
        free(arr);
        return;
    }
    
    // 生成随机浮点数
    srand(time(NULL));
    for (int i = 0; i < size; i++) {
        arr[i] = (float)rand() / RAND_MAX * 100.0f;
    }
    
    // 将原始随机数据写入文件
    write_float_array_to_file("original_float_data.txt", arr, size);
    
    // 测试选择排序
    memcpy(temp, arr, size * sizeof(float));
    double start = get_time();
    selection_sort(temp, size, sizeof(float), compare_float);
    double end = get_time();
    printf("Selection Sort: %.6f seconds\n", end - start);
    write_float_array_to_file("selection_sort_float_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(float), compare_float);
    
    // 测试插入排序
    memcpy(temp, arr, size * sizeof(float));
    start = get_time();
    insertion_sort(temp, size, sizeof(float), compare_float);
    end = get_time();
    printf("Insertion Sort: %.6f seconds\n", end - start);
    write_float_array_to_file("insertion_sort_float_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(float), compare_float);
    
    // 测试冒泡排序
    memcpy(temp, arr, size * sizeof(float));
    start = get_time();
    bubble_sort(temp, size, sizeof(float), compare_float);
    end = get_time();
    printf("Bubble Sort:    %.6f seconds\n", end - start);
    write_float_array_to_file("bubble_sort_float_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(float), compare_float);
    
    // 测试归并排序
    memcpy(temp, arr, size * sizeof(float));
    start = get_time();
    merge_sort(temp, size, sizeof(float), compare_float);
    end = get_time();
    printf("Merge Sort:     %.6f seconds\n", end - start);
    write_float_array_to_file("merge_sort_float_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(float), compare_float);
    
    // 测试快速排序
    memcpy(temp, arr, size * sizeof(float));
    start = get_time();
    quick_sort(temp, size, sizeof(float), compare_float);
    end = get_time();
    printf("Quick Sort:     %.6f seconds\n", end - start);
    write_float_array_to_file("quick_sort_float_result.txt", temp, size);
    verify_sorted(temp, size, sizeof(float), compare_float);
    
    // 测试堆排序
    memcpy(temp, arr, size * sizeof(float));
    start = get_time();
    heap_sort(temp, size, sizeof(float), compare_float);
    end = get_time();
    printf("Heap Sort:      %.6f seconds\n", end - start);
    write_float_array_to_file("heap_sort_float_result.txt", temp, size);

    
    // 验证排序结果
    verify_sorted(temp, size, sizeof(float), compare_float);
    
    free(arr);
    free(temp);
}

void test_struct_sort(int size) {
    printf("Student Struct Sorting Performance:\n");
    printf("-----------------------------------\n");
    
    Student *students = (Student *)malloc(size * sizeof(Student));
    if (students == NULL) {
        printf("Error: Memory allocation failed for students array\n");
        return;
    }
    
    Student *temp = (Student *)malloc(size * sizeof(Student));
    if (temp == NULL) {
        printf("Error: Memory allocation failed for temp array\n");
        free(students);
        return;
    }
    
    // 生成随机学生数据
    srand(time(NULL));
    const char *names[] = {
        "Alice", "Bob", "Charlie", "David", "Eva",
        "Frank", "Grace", "Henry", "Ivy", "Jack",
        "Kevin", "Linda", "Mike", "Nancy", "Oscar",
        "Paul", "Queen", "Rose", "Sam", "Tom"
    };
    const int num_names = sizeof(names) / sizeof(names[0]);
    
    for (int i = 0; i < size; i++) {
        students[i].id = i + 1;
        strcpy(students[i].name, names[rand() % num_names]);
        students[i].score = (float)(rand() % 1000) / 10.0f;
    }
    
    // 将原始学生数据写入文件
    write_student_array_to_file("original_student_data.csv", students, size);
    
    // 打印前5个学生数据作为样本
    printf("\nSample of unsorted data (first 5 students):\n");
    print_students(students, size < 5 ? size : 5);
    printf("\n");
    
    // 测试选择排序
    memcpy(temp, students, size * sizeof(Student));
    double start = get_time();
    selection_sort(temp, size, sizeof(Student), compare_student);
    double end = get_time();
    printf("Selection Sort: %.6f seconds\n", end - start);
    write_student_array_to_file("selection_sort_student_result.csv", temp, size);
    verify_sorted(temp, size, sizeof(Student), compare_student);
    
    // 测试插入排序
    memcpy(temp, students, size * sizeof(Student));
    start = get_time();
    insertion_sort(temp, size, sizeof(Student), compare_student);
    end = get_time();
    printf("Insertion Sort: %.6f seconds\n", end - start);
    write_student_array_to_file("insertion_sort_student_result.csv", temp, size);
    verify_sorted(temp, size, sizeof(Student), compare_student);
    
    // 测试冒泡排序
    memcpy(temp, students, size * sizeof(Student));
    start = get_time();
    bubble_sort(temp, size, sizeof(Student), compare_student);
    end = get_time();
    printf("Bubble Sort:    %.6f seconds\n", end - start);
    write_student_array_to_file("bubble_sort_student_result.csv", temp, size);
    verify_sorted(temp, size, sizeof(Student), compare_student);
    
    // 测试归并排序
    memcpy(temp, students, size * sizeof(Student));
    start = get_time();
    merge_sort(temp, size, sizeof(Student), compare_student);
    end = get_time();
    printf("Merge Sort:     %.6f seconds\n", end - start);
    write_student_array_to_file("merge_sort_student_result.csv", temp, size);
    verify_sorted(temp, size, sizeof(Student), compare_student);
    
    // 测试快速排序
    memcpy(temp, students, size * sizeof(Student));
    start = get_time();
    quick_sort(temp, size, sizeof(Student), compare_student);
    end = get_time();
    printf("Quick Sort:     %.6f seconds\n", end - start);
    write_student_array_to_file("quick_sort_student_result.csv", temp, size);
    verify_sorted(temp, size, sizeof(Student), compare_student);
    
    // 测试堆排序
    memcpy(temp, students, size * sizeof(Student));
    start = get_time();
    heap_sort(temp, size, sizeof(Student), compare_student);
    end = get_time();
    printf("Heap Sort:      %.6f seconds\n", end - start);
    write_student_array_to_file("heap_sort_student_result.csv", temp, size);
    verify_sorted(temp, size, sizeof(Student), compare_student);
    
    // 打印排序后的前5个学生数据
    printf("\nSample of sorted data (first 5 students):\n");
    print_students(temp, size < 5 ? size : 5);
    
    // 验证最终排序结果
    verify_sorted(temp, size, sizeof(Student), compare_student);
    
    free(students);
    free(temp);
}