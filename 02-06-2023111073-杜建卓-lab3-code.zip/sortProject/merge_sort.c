#include "sort.h"

static void merge(void *base, size_t left, size_t mid, size_t right, size_t size, CompareFunc compar, char *temp) {
    size_t i = left, j = mid + 1, k = 0;
    char *arr = (char *)base;
    
    while (i <= mid && j <= right) {
        if (compar(arr + i * size, arr + j * size) <= 0) {
            memcpy(temp + k * size, arr + i * size, size);
            i++;
        } else {
            memcpy(temp + k * size, arr + j * size, size);
            j++;
        }
        k++;
    }
    
    // 复制剩余元素
    while (i <= mid) {
        memcpy(temp + k * size, arr + i * size, size);
        i++;
        k++;
    }
    
    while (j <= right) {
        memcpy(temp + k * size, arr + j * size, size);
        j++;
        k++;
    }
    
    // 将排序后的数据复制回原数组
    memcpy(arr + left * size, temp, k * size);
}

static void merge_sort_helper(void *base, size_t left, size_t right, size_t size, CompareFunc compar, char *temp) {
    if (left < right) {
        size_t mid = left + (right - left) / 2;
        
        merge_sort_helper(base, left, mid, size, compar, temp);
        merge_sort_helper(base, mid + 1, right, size, compar, temp);
        merge(base, left, mid, right, size, compar, temp);
    }
}

void merge_sort(void *base, size_t nmemb, size_t size, CompareFunc compar) {
    if (!base || nmemb <= 1 || !size || !compar) return;
    
    // 小数组使用插入排序
    if (nmemb <= 10) {
        insertion_sort(base, nmemb, size, compar);
        return;
    }
    
    char *temp = (char *)malloc(nmemb * size);
    if (!temp) {
        perror("Memory allocation failed in merge_sort");
        return;
        return;
    }
    
    merge_sort_helper(base, 0, nmemb - 1, size, compar, temp);
    free(temp);
}