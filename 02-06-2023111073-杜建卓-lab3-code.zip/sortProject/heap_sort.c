#include "sort.h"

static void heapify(void *base, size_t n, size_t i, size_t size, CompareFunc compar) {
    char *arr = (char *)base;
    size_t largest = i;
    size_t left = 2 * i + 1;
    size_t right = 2 * i + 2;
    
    if (left < n && compar(arr + left * size, arr + largest * size) > 0) {
        largest = left;
    }
    
    if (right < n && compar(arr + right * size, arr + largest * size) > 0) {
        largest = right;
    }
    
    if (largest != i) {
        swap(arr + i * size, arr + largest * size, size);
        heapify(base, n, largest, size, compar);
    }
}

void heap_sort(void *base, size_t nmemb, size_t size, CompareFunc compar) {
    if (nmemb <= 1) return;
    
    char *arr = (char *)base;
    
    // 构建最大堆
    for (size_t i = nmemb / 2; i > 0; i--) {
        heapify(base, nmemb, i - 1, size, compar);
    }
    
    // 逐个提取元素
    for (size_t i = nmemb; i > 1; i--) {
        swap(arr, arr + (i - 1) * size, size);
        heapify(base, i - 1, 0, size, compar);
    }
}