#ifndef SORT_H
#define SORT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

// 比较函数类型定义
typedef int (*CompareFunc)(const void*, const void*);

// 结构体定义
typedef struct {
    int id;
    char name[20];
    float score;
} Student;

// 排序算法函数声明
void selection_sort(void *base, size_t nmemb, size_t size, CompareFunc compar);
void insertion_sort(void *base, size_t nmemb, size_t size, CompareFunc compar);
void bubble_sort(void *base, size_t nmemb, size_t size, CompareFunc compar);
void merge_sort(void *base, size_t nmemb, size_t size, CompareFunc compar);
void quick_sort(void *base, size_t nmemb, size_t size, CompareFunc compar);
void heap_sort(void *base, size_t nmemb, size_t size, CompareFunc compar);

// 比较函数声明
int compare_int(const void *a, const void *b);
int compare_float(const void *a, const void *b);
int compare_student(const void *a, const void *b);

// 辅助函数声明
void swap(void *a, void *b, size_t size);
void print_array_int(int *arr, int n);
void print_array_float(float *arr, int n);
void print_students(Student *students, int n);
void verify_sorted(void *arr, size_t nmemb, size_t size, CompareFunc compar);
   

#endif