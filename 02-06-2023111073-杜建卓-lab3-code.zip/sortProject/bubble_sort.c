#include "sort.h"

void bubble_sort(void *base, size_t nmemb, size_t size, CompareFunc compar) {
    char *arr = (char *)base;
    
    for (size_t i = 0; i < nmemb - 1; i++) {
        int swapped = 0;
        
        for (size_t j = 0; j < nmemb - 1 - i; j++) {
            if (compar(arr + j * size, arr + (j + 1) * size) > 0) {
                swap(arr + j * size, arr + (j + 1) * size, size);
                swapped = 1;
            }
        }
        
        // 如果没有发生交换，说明已经排序完成
        if (!swapped) {
            break;
        }
    }
}