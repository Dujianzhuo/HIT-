#include "sort.h"

static size_t partition(void *base, size_t low, size_t high, size_t size, CompareFunc compar) {
    char *arr = (char *)base;
    char *pivot = (char *)malloc(size);
    if (!pivot) {
        perror("Memory allocation failed in partition");
        return high; // 返回high表示分区失败
    }
    
    memcpy(pivot, arr + high * size, size);
    size_t i = low;
    
    for (size_t j = low; j < high; j++) {
        if (compar(arr + j * size, pivot) <= 0) {
            swap(arr + i * size, arr + j * size, size);
            i++;
        }
    }
    
    swap(arr + i * size, arr + high * size, size);
    free(pivot);
    return i;
}

static void quick_sort_helper(void *base, size_t low, size_t high, size_t size, CompareFunc compar, int depth) {
    // 递归深度限制，切换到插入排序
    if (depth <= 0) {
        insertion_sort(base + low * size, high - low + 1, size, compar);
        return;
    }
    
    if (low < high) {
        // 对于小数组使用插入排序
        if (high - low + 1 <= 10) {
            insertion_sort(base + low * size, high - low + 1, size, compar);
            return;
        }
        
        size_t pi = partition(base, low, high, size, compar);
        
        if (pi > 0) {
            quick_sort_helper(base, low, pi - 1, size, compar, depth - 1);
        }
        quick_sort_helper(base, pi + 1, high, size, compar, depth - 1);
    }
}

void quick_sort(void *base, size_t nmemb, size_t size, CompareFunc compar) {
    if (!base || nmemb <= 1 || !size || !compar) return;
    
    // 计算最大递归深度，2*log2(n)通常足够
    int max_depth = 2 * (int)(sizeof(size_t) * 8 - __builtin_clzl(nmemb));
    quick_sort_helper(base, 0, nmemb - 1, size, compar, max_depth);
}