#include "sort.h"

// 比较函数实现
int compare_int(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

int compare_float(const void *a, const void *b) {
    float diff = (*(float*)a - *(float*)b);
    return (diff > 0) ? 1 : ((diff < 0) ? -1 : 0);
}

int compare_student(const void *a, const void *b) {
    const Student *sa = (const Student*)a;
    const Student *sb = (const Student*)b;
    
    // 先按分数排序，分数相同按ID排序
    if (sa->score != sb->score) {
        return (sa->score > sb->score) ? -1 : 1; // 降序排列
    }
    return sa->id - sb->id;
}

// 交换函数
void swap(void *a, void *b, size_t size) {
    char *temp = (char *)malloc(size);
    if (!temp) {
        perror("Memory allocation failed");
        return;
    }
    
    memcpy(temp, a, size);
    memcpy(a, b, size);
    memcpy(b, temp, size);
    
    free(temp);
}

// 打印函数
void print_array_int(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
        if ((i + 1) % 10 == 0) printf("\n");
    }
    printf("\n");
}

void print_array_float(float *arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%.2f ", arr[i]);
        if ((i + 1) % 10 == 0) printf("\n");
    }
    printf("\n");
}

void print_students(Student *students, int n) {
    for (int i = 0; i < n; i++) {
        printf("ID: %d, Name: %s, Score: %.2f\n", 
               students[i].id, students[i].name, students[i].score);
    }
}

void verify_sorted(void *arr, size_t nmemb, size_t size, CompareFunc compar) {
    char *data = (char *)arr;
    int sorted = 1;
    
    for (size_t i = 0; i < nmemb - 1; i++) {
        if (compar(data + i * size, data + (i + 1) * size) > 0) {
            sorted = 0;
            printf("Sort error at index %zu\n", i);
            break;
        }
    }
    printf("Sort verification: %s\n", sorted ? "PASSED" : "FAILED");
}
